#ifndef __DROP_PRIV_H
#define __DROP_PRIV_H

void drop_priv(void);

#endif /* __DROP_PRIV_H */
