#ifndef XNU_DARWINTEST_UTILS_H
#define XNU_DARWINTEST_UTILS_H

#include <stdbool.h>

/* Misc. utility functions for writing darwintests. */
bool is_development_kernel(void);
#endif /* !defined(XNU_DARWINTEST_UTILS_H) */
